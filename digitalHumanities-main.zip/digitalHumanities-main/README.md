Basic examples for a course I teach in Digital Humanities.

First example:

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/emmanuelferragne/digitalHumanities/HEAD) 
